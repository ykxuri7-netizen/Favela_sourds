# Favela Sound Menu — Android Prototype 0.1

A minimal Android overlay panel built in Java with no third-party runtime dependencies.

## What works
- Android app shell.
- User-granted overlay permission.
- Dark/yellow floating panel with sound-equipment demo categories.
- Close button and draggable header/footer.
- GitHub Actions debug APK workflow.

## Not implemented
The catalog items are demonstrations only. This prototype does not inspect or modify Rebaixados de Favela's memory, save data, or internal equipment. Real integration requires a verified supported interface for the installed game version.

## Build
Push this repository to GitHub. Open **Actions** and run **Build Favela Sound Menu APK**, or push to `main`. Download the `favela-sound-menu-debug` artifact from the completed workflow. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Install
Open the installed app, tap **Ativar painel flutuante**, allow “Display over other apps” in Android settings, return to the app, and tap **Abrir painel agora**. The panel should appear over the current app. Tap **Fechar** to dismiss it.

## Technical notes
- Java 17-compatible source
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Compile SDK 35, min SDK 23

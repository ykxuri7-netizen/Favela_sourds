package br.com.favelasoundmenu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 2001;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showScreen();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255, 176, 0)));
        return b;
    }

    private void showScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(20));
        root.setBackgroundColor(Color.rgb(16, 17, 20));

        TextView title = text("FAVELA SOUND MENU", 23, Color.rgb(255, 176, 0));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView intro = text("Protótipo 0.1 • painel flutuante", 15, Color.WHITE);
        root.addView(intro, new LinearLayout.LayoutParams(-1, dp(36)));

        TextView details = text(
            "Catálogo de demonstração. Este APK mostra uma interface sobre outros apps; " +
            "ele ainda não modifica os dados internos do Rebaixados de Favela.",
            14, Color.LTGRAY);
        details.setPadding(0, dp(8), 0, dp(16));
        root.addView(details, new LinearLayout.LayoutParams(-1, -2));

        Button enable = button("Ativar painel flutuante");
        enable.setOnClickListener(v -> requestOverlay());
        root.addView(enable, new LinearLayout.LayoutParams(-1, dp(54)));

        Button open = button("Abrir painel agora");
        open.setOnClickListener(v -> startOverlayIfAllowed());
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(-1, dp(54));
        openParams.topMargin = dp(10);
        root.addView(open, openParams);

        TextView note = text(
            "Depois de autorizar a sobreposição nas configurações do Android, volte aqui e toque em “Abrir painel agora”.",
            13, Color.GRAY);
        note.setPadding(0, dp(20), 0, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY);
        } else {
            startOverlayIfAllowed();
        }
    }

    private void startOverlayIfAllowed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            requestOverlay();
            return;
        }
        Intent service = new Intent(this, OverlayService.class);
        startService(service);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            showScreen();
        }
    }
}
